
<?php $__env->startSection('title'); ?>
Bookings | A Logistics Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-contents'); ?>

<?php if(session('status')): ?>
   <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

        <a href="" class="close pull-right">&times;</a>
   </div>
<?php elseif(session('warning')): ?>
   <div class="alert alert-danger" role="alert">
        <?php echo e(session('warning')); ?>

        <a href="" class="close pull-right">&times;</a>
   </div>    
<?php endif; ?>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Bookings <a href="<?php echo e(url('/add-booking')); ?>" class="btn btn-success" data-toggle="modal" data-target="#bookingModal">Add</a></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Bookings List</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Sl.</th>
                            <th>Tracking Id</th>
                            <th>Company Name</th>
                            <th>Company Address</th>
                            <th>From booking</th>
                            <th>From Port</th>
                            <th>Destination booking</th>
                            <th>Destination Port</th>
                            <th>Container</th>
                            <th>Goods</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($booking->id); ?></td>
                                <td class="text-center"><?php echo e($booking->tracking_id); ?> <a href="<?php echo e(url('/trackings/'.$booking->tracking_id)); ?>" class="btn btn-primary btn-sm"> <i class="fa fa-eye"></i> </a></td>
                                <td><?php echo e($booking->company_name); ?></td>
                                <td><?php echo e($booking->company_address); ?></td>
                                <td><?php echo e($booking->from_c->name); ?></td>
                                <td><?php echo e($booking->from_p->name); ?></td>
                                <td><?php echo e($booking->destination_c->name); ?></td>
                                <td><?php echo e($booking->destination_p->name); ?></td>
                                <td><?php echo e($booking->container_info->name); ?></td>
                                <td><?php echo e($booking->goods); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(url('/edit-booking/'.$booking->tracking_id)); ?>" class="btn btn-primary">Edit</a>
                                        
                                        <a href="<?php echo e(url('/delete-booking/'.$booking->tracking_id)); ?>" class="btn btn-danger">Delete</a>
                                    </div>

                                        <!-- Are You Sure Modal-->
                                        
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- booking Add Modal -->
    <div class="modal fade" id="bookingModal" tabindex="-1" role="dialog" aria-labelledby="bookingModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-primary" id="bookingModalLabel"> <b>Add Booking</b> </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="user" action="<?php echo e(url('/save-booking')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-6 mb-3 mb-sm-0">
                                <label for="company_name" class="text-primary"> <b>Company Name <span class="text-danger">*</span></b> </label>
                                <input type="text" name="company_name" class="form-control <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="company_name"
                                    placeholder="Company Name" required="">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>   
                                <br>
                            </div>

                            <div class="col-6 mb-3 mb-sm-0">
                                <label for="company_address" class="text-primary"> <b>Company Address <span class="text-danger">*</span></b> </label>
                                <input type="text" name="company_address" class="form-control <?php $__errorArgs = ['company_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="company_address"
                                    placeholder="Company Address" required="">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['company_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger"><?php echo e($message); ?></p> 
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span> 
                                <br>
                            </div>

                            <div class="col-6 mb-3 mb-sm-0">
                                <label for="from_country" class="text-primary"> <b>From Country <span class="text-danger">*</span></b> </label>
                                <select name="from_country" id="from_country" required="" class="form-control <?php $__errorArgs = ['from_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option>Select A Country</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <br>
                            </div>

                            <div class="col-6 mb-3 mb-sm-0">
                                <label for="from_port" class="text-primary"> <b>From Port <span class="text-danger">*</span></b> </label>
                                <select name="from_port" id="from_port" required="" class="form-control <?php $__errorArgs = ['from_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option>Select A Port</option>
                                    
                                </select>
                                <br>
                            </div>

                            <div class="col-6 mb-3 mb-sm-0">
                                <label for="destination_country" class="text-primary"> <b>Destination Country <span class="text-danger">*</span></b> </label>
                                <select name="destination_country" id="destination_country" required="" class="form-control <?php $__errorArgs = ['destination_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option>Select A Country</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <br>
                            </div>

                            <div class="col-6 mb-3 mb-sm-0">
                                <label for="destination_port" class="text-primary"> <b>Destination Port <span class="text-danger">*</span></b> </label>
                                <select name="destination_port" id="destination_port" required="" class="form-control <?php $__errorArgs = ['destination_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option>Select A Port</option>
                                    
                                </select>
                                <br>
                            </div>

                            <div class="col-12 mb-3 mb-sm-0">
                                <label for="container_id" class="text-primary"> <b>Container Type <span class="text-danger">*</span></b> </label>
                                <select name="container_id" id="container_id" required="" class="form-control <?php $__errorArgs = ['container_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option>Select A Container Type</option>
                                    <?php $__currentLoopData = $containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($container->id); ?>"><?php echo e($container->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <br>
                            </div>

                            <div class="col-12 mb-3 mb-sm-0">
                                <label for="booking_date" class="text-primary"> <b>Booking Date <span class="text-danger">*</span></b> </label>
                                <input type="date" name="booking_date" class="form-control <?php $__errorArgs = ['booking_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="booking_date" required="">
                                <br>
                            </div>

                            <div class="col-12 mb-3 mb-sm-0">
                                <label for="goods" class="text-primary"> <b>Goods <span class="text-danger">*</span></b> </label>
                                <textarea name="goods" id="goods" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2">Description of your goods</textarea> 
                                <br>
                            </div>

                            <div class="col-12 mb-3 mb-sm-0">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>



</div>
<!-- /.container-fluid -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marine-liner\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>