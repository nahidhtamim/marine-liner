
<?php $__env->startSection('title'); ?>
Edit Booking | A Logistics Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-contents'); ?>

<?php if(session('status')): ?>
   <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

        <a class="close pull-right">&times;</a>
   </div>
<?php elseif(session('warning')): ?>
   <div class="alert alert-danger" role="alert">
        <?php echo e(session('warning')); ?>

        <a class="close pull-right">&times;</a>
   </div>    
<?php endif; ?>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Bookings</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Bookings List</h6>
        </div>
        <div class="card-body">
            <form class="user" action="<?php echo e(url('/update-booking/'.$booking->tracking_id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-6 mb-3 mb-sm-0">
                        <label for="company_name" class="text-primary"> <b>Company Name <span class="text-danger">*</span></b> </label>
                        <input type="text" name="company_name" class="form-control <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="company_name"
                            value="<?php echo e($booking->company_name); ?>" required="">
                            <span class="text-danger">
                                <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>   
                        <br>
                    </div>

                    <div class="col-6 mb-3 mb-sm-0">
                        <label for="company_address" class="text-primary"> <b>Company Address <span class="text-danger">*</span></b> </label>
                        <input type="text" name="company_address" class="form-control <?php $__errorArgs = ['company_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="company_address"
                        value="<?php echo e($booking->company_address); ?>" required="">
                            <span class="text-danger">
                                <?php $__errorArgs = ['company_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>   
                        <br>
                    </div>

                    <div class="col-6 mb-3 mb-sm-0">
                        <label for="from_country" class="text-primary"> <b>From Country <span class="text-danger">*</span></b> </label>
                        <select name="from_country" id="from_country" required="" class="form-control <?php $__errorArgs = ['from_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="<?php echo e($booking->from_country); ?>"><?php echo e($booking->from_c->name); ?></option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                    </div>

                    <div class="col-6 mb-3 mb-sm-0">
                        <label for="from_port" class="text-primary"> <b>From Port <span class="text-danger">*</span></b> </label>
                        <select name="from_port" id="from_port" required="" class="form-control <?php $__errorArgs = ['from_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="<?php echo e($booking->from_port); ?>"><?php echo e($booking->from_p->name); ?></option>
                            
                        </select>
                        <br>
                    </div>

                    <div class="col-6 mb-3 mb-sm-0">
                        <label for="destination_country" class="text-primary"> <b>Destination Country <span class="text-danger">*</span></b> </label>
                        <select name="destination_country" id="destination_country" required="" class="form-control <?php $__errorArgs = ['destination_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="<?php echo e($booking->destination_country); ?>"><?php echo e($booking->destination_c->name); ?></option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                    </div>

                    <div class="col-6 mb-3 mb-sm-0">
                        <label for="destination_port" class="text-primary"> <b>Destination Port <span class="text-danger">*</span></b> </label>
                        <select name="destination_port" id="destination_port" required="" class="form-control <?php $__errorArgs = ['destination_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="<?php echo e($booking->destination_port); ?>"><?php echo e($booking->destination_p->name); ?></option>
                            
                        </select>
                        <br>
                    </div>

                    <div class="col-12 mb-3 mb-sm-0">
                        <label for="container_id" class="text-primary"> <b>Container Type <span class="text-danger">*</span></b> </label>
                        <select name="container_id" id="container_id" required="" class="form-control <?php $__errorArgs = ['container_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="<?php echo e($booking->container_id); ?>"><?php echo e($booking->container_info->name); ?></option>
                            <?php $__currentLoopData = $containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($container->id); ?>"><?php echo e($container->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                    </div>

                    <div class="col-12 mb-3 mb-sm-0">
                        <label for="booking_date" class="text-primary"> <b>Booking Date <span class="text-danger">*</span></b> </label>
                        <input type="date" name="booking_date" class="form-control <?php $__errorArgs = ['booking_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="booking_date" required="" value="<?php echo e($booking->booking_date); ?>">   
                        <br>
                    </div>

                    <div class="col-12 mb-3 mb-sm-0">
                        <label for="goods" class="text-primary"> <b>Goods <span class="text-danger">*</span></b> </label>
                        <textarea name="goods" id="goods" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"><?php echo e($booking->goods); ?></textarea>  
                        <br>
                    </div>

                    <div class="col-12 mb-3 mb-sm-0">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /.container-fluid -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marine-liner\resources\views/admin/bookings/edit.blade.php ENDPATH**/ ?>