

<?php $__env->startSection('content'); ?>


<section class="bg-gradient-to-l from-red-50 to-indigo-50">
  <div class="h-full text-gray-800 wrapper">
      <div class="grid md:grid-cols-2 gap-12">
          <div class="flex justify-center items-center md:order-last">
              <div class="bg-gradient-to-br from-sky-700 to-sky-500 p-11 rounded-full shadow-inner drop-shadow-md">
                  <img src="<?php echo e(asset('frontend/assets/images/icons8-booking-64.png')); ?>" alt="">
              </div>
          </div>
          <div class="flex items-center">
              <h1>List of My Bookings</h1>
          </div>
      </div>
  </div>
</section>
<!-- tracking table start -->
<section class="wrapper">
    <div class="space-y-8">
        <!--tracking detail start -->
        <div class="flex items-end flex-col space-y-1">
            <div class="flex space-x-2 items-center">
                <div>
                    <span
                        class="whitespace-nowrap px-2 bg-blue-500 rounded-md font-semibold text-white text-xs">Container
                        to consignee
                    </span>
                </div>
                <h3 class="font-semibold">My Bookings</h3>
            </div>
        </div>
        <!--tracking detail end -->

        <?php if($bookings->count() == 0): ?>

        <!-- tracking label start -->
        <div class="flex border flex-col md:flex-row py-3">
            <div class="flex items-center">
                <div class="py-2 px-4 text-center">
                    <h6 class="font-semibold text-center">No Booking Yet</h6>
                </div>
            </div>
        </div>
        <!-- tracking label end -->

        <?php elseif($bookings->count() >= 1): ?>

        <!-- tracking table start -->

        <div class="overflow-x-auto relative">
            <table class="w-full text-sm text-left text-gray-500">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr class="text-center">
                        <th scope="col" class="py-3 px-6">Track The Booking</th>
                        <th scope="col" class="py-3 px-6">Booking ID</th>
                        <th scope="col" class="py-3 px-6">Tracking ID</th>
                        <th scope="col" class="py-3 px-6">Company Name</th>
                        <th scope="col" class="py-3 px-6">Company Address</th>
                        <th scope="col" class="py-3 px-6">From Country</th>
                        <th scope="col" class="py-3 px-6">From Port</th>
                        <th scope="col" class="py-3 px-6">Destination Country</th>
                        <th scope="col" class="py-3 px-6">Destination Port</th>
                        <th scope="col" class="py-3 px-6">Container</th>
                        <th scope="col" class="py-3 px-6">Booking Date</th>
                        <th scope="col" class="py-3 px-6">Details</th>
                        <th scope="col" class="py-3 px-6">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white border-b">
                        <td class="py-4 px-6 whitespace-nowrap">
                          <a href="<?php echo e(url('/tracking/'.$booking->tracking_id)); ?>" class="">
                            <img src="<?php echo e(asset('frontend/assets/images/icons8-ship-48.png')); ?>" alt="">
                          </a>
                        </td>
                        <td class="py-4 px-6 whitespace-nowrap">
                          <?php echo e($booking->booking_id); ?>

                        </td>
                        <td class="py-4 px-6 whitespace-nowrap">
                          <?php echo e($booking->tracking_id); ?>

                        </td>
                        <td class="py-4 px-6 whitespace-nowrap"><?php echo e($booking->company_name); ?></td>
                        <td class="py-4 px-6 whitespace-nowrap"><?php echo e($booking->company_address); ?></td>
                        <td class="py-4 px-6 whitespace-nowrap"><?php echo e($booking->from_c->name); ?></td>
                        <td class="py-4 px-6 whitespace-nowrap"><?php echo e($booking->from_p->name); ?></td>
                        <td class="py-4 px-6 whitespace-nowrap"><?php echo e($booking->destination_c->name); ?></td>
                        <td class="py-4 px-6 whitespace-nowrap"><?php echo e($booking->destination_p->name); ?></td>
                        <td class="py-4 px-6 whitespace-nowrap"><?php echo e($booking->container_info->name); ?></td>
                        <td class="py-4 px-6 whitespace-nowrap">
                          <span class="flex items-center space-x-1">
                              <svg xmlns="http://www.w3.org/2000/svg"
                                  class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                                  stroke-width="2">
                                  <path stroke-linecap="round" stroke-linejoin="round"
                                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              <span> <?php echo e($booking->booking_date); ?> </span>
                            </span>
                      </td>
                        <td class="py-4 px-6 whitespace-nowrap"><?php echo e($booking->goods); ?></td>
                        <td class="py-4 px-6 whitespace-nowrap">
                          <?php if($booking->status == '0'): ?>
                          <span class="whitespace-nowrap py-1 px-2 bg-blue-50 rounded-md font-semibold text-yellow-500 text-xs">
                              On Hold
                          </span>
                          <?php elseif($booking->status == '1'): ?>
                          <span class="whitespace-nowrap py-1 px-2 bg-blue-50 rounded-md font-semibold text-green-500 text-xs">
                              Active
                          </span>
                          <?php else: ?>
                          <span class="whitespace-nowrap py-1 px-2 bg-blue-50 rounded-md font-semibold text-blue-500 text-xs">
                              Completed
                          </span>
                          <?php endif; ?>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- tracking table end -->

        <?php endif; ?>
    </div>
</section>
<!-- tracking table end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marine-liner\resources\views/my-bookings.blade.php ENDPATH**/ ?>